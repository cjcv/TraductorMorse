﻿using System;
using System.Collections.Generic;

namespace Traductor_a_Morse
{
    class MainClass
    {
        static Dictionary<char, string> letrasAMorse;

        public static void Main()
        {
            letrasAMorse = new Dictionary<char, string>
            {
                {'a', ". -   "}, {'b', "- . . .   " }, {'c', "- . - .   " }, {'d', "- . .   "}, {'e', ".   "}, {'f', ". . - .   " },
                {'g', "- - .   "}, {'h', ". . . .   "}, {'i', ". .   "}, {'j', ". - - -   "}, {'k', "- . -   "}, {'l', ". - . .   "},
                {'m', "- -   "}, {'n', "- .   "}, {'ñ', "- - . - -   "}, {'o', "- - -   "}, {'p', ". - - .   "}, {'q', "- - . -   "},
                {'r', "- . -   "}, {'s', ". . .   "}, {'t', "-   "}, {'u', ". . -   "}, {'v', ". . . -   "}, {'w', ". - -   "},
                {'x', "- . . -   "}, {'y', "- . - -   "}, {'z', "- - . .   "},

                {'1', ". - - - -   "}, {'2', ". . - - -   "}, {'3', ". . . - -   "}, {'4', ". . . . -   "}, {'5', ". . . . .   "},
                {'6', "- . . . .   "}, {'7', "- - . . .   "}, {'8', "- - - . .   "}, {'9', "- - - - .   "}, {'0', "- - - - -   "},

                {'.', ". - . - . -   "}, {',', "- - . . - -   "}, {'?', ". . - - . .   "}, {'/', "- . . - .   "}, {'!', "- . - . - -   "}, {' ', "       "},
                {'(', "-.--. "}, {')', "-.--.- "}, {'&', ".-... "}, {':', "---... "}, {';', "-.-.-. "}, {'=', "-...- "},
                {'+', ".-.-. "}, {'-', "-....- "}, {'_', "..--.- "}, {'"', ".-..-. "}, {'$', "...-..- "}, {'@', ".--.-. "},
                {'\'', ". - - - - .   "}, {'¿', ". . - . -   "}, {'¡', "- - . . . -   "}
            };
            Console.Title = "TRADUCTOR A MORSE";
            menu();
        }

        static void menu()
        {
            Console.WriteLine(Console.Title);
            Console.WriteLine("Ingresa un texto:");
            Console.WriteLine(traducir(Console.ReadLine().ToString()));
            Console.ReadKey();
            Console.WriteLine("Quieres continuar traduciendo \n - s/n -");
            if (Console.ReadLine() == "s")
            {
                Console.Clear();
                menu();
            }
        }

        static string traducir(string entrada)
        {
            string salida = "";
            char[] letras = entrada.ToLower().ToCharArray();

            for (int traducidas = 0; traducidas < letras.Length; traducidas++)
            {
                if (letrasAMorse.ContainsKey(letras[traducidas]))
                {
                    salida += letrasAMorse[letras[traducidas]];
                }
                else { salida += "?"; }
            }
            return salida;
        }
    }
}